#include <iostream>
#include <string>
#include <algorithm>
#include <unistd.h>
#include <filesystem>
#include <cstdlib>
#include <fstream>
#include <vector>
#include <stdio.h>
#include <termios.h>
namespace fs = std::filesystem;
#define clear system("clear");
using namespace std;

std::string pkg;
std::string pkggit;
std::string directoryPath;
std::string currentDirectory = std::filesystem::current_path().string();
std::vector<std::string> dependencies;

void pausecmd() {
    struct termios oldt, newt;
    int ch;
    // Get the current terminal settings
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    // Set the terminal to raw mode to capture key presses without Enter key
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    printf("Press any key to continue");
    ch = getchar();
    // Restore the terminal to its original settings
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    printf("\n");
}

void readDependencies(const std::string& filename) {
    std::ifstream file(filename);

    if (!file.is_open()) {
        std::cerr << "Error opening file: " << filename << std::endl;
        return;
    }

    std::string line;
    while (std::getline(file, line)) {
        // Assuming dependencies are listed in the 'depends' or 'makedepends' variables
        if (line.find("depends=(") != std::string::npos ||
            line.find("makedepends=(") != std::string::npos) {
            size_t start = line.find_first_of('(');
            size_t end = line.find_last_of(')');
            if (start != std::string::npos && end != std::string::npos) {
                std::string deps = line.substr(start + 1, end - start - 1);
                size_t pos = 0;
                while ((pos = deps.find(',')) != std::string::npos) {
                    // Remove leading/trailing spaces and single quotes
                    std::string dep = deps.substr(0, pos);
                    dep.erase(0, dep.find_first_not_of(" '"));
                    dep.erase(dep.find_last_not_of(" '") + 1);
                    dependencies.push_back(dep);
                    deps.erase(0, pos + 1);
                }
                // Add the last dependency
                deps.erase(0, deps.find_first_not_of(" '"));
                deps.erase(deps.find_last_not_of(" '") + 1);
                dependencies.push_back(deps);
            }
        }
    }

    file.close();
}


void detectsudo() {
    if (geteuid() == 0) {
    std::cout << "SUDO is not supported! Please rerun the program without SUDO" << std::endl;
    exit(1);
}
}

void fail() {
    clear
    std::cout << "Package dosn't exist on the AUR\n";
    std::filesystem::remove_all(directoryPath);
}

bool hasFiles(const std::string& path) {
    for (const auto& entry : fs::directory_iterator(path)) {
        if (entry.is_regular_file()) {
            // Found a file
            return true;
        }
    }
    // No files found
    return false;
}
int main(int argc, char* argv[]) {
    if (argc != 2) {
        std::cerr << "Usage: " << argv[0] << " <package_name>\n";
        exit(1);
    }
    clear
    std::string pkg = argv[1];
    std::transform(pkg.begin(), pkg.end(), pkg.begin(), ::tolower);

    if (pkg == "createrepo") {
    std::string home_dir = std::getenv("HOME");
    std::string file_path = home_dir + "/.ssh/aur.pub";
    std::ifstream file(file_path);
    if (file.is_open()) {
        std::cout << "AUR ssh key found." << std::endl;
        file.close();
    } else {
        std::cout << "No AUR ssh file found" << std::endl;
        exit(1);
    }
        const char* command = "makepkg --printsrcinfo > .SRCINFO";
        int excode = std::system(command);
        if (excode == !0) {
            std::cout << "Failed to read from PKGBUILD file!";
        }
        std::cout << "Whats the packages name?\n";
        std::string input;
        std::cin >> input;
        std::string pkggit = input + ".git";
    std::cout << "Checking if package '" << pkg << "' exists\n";
    const std::string directoryPath = currentDirectory + "/" + pkg;
    std::filesystem::remove_all(directoryPath);
    system(("git -c init.defaultbranch=master clone ssh://aur@aur.archlinux.org/ " + pkggit).c_str());
    if (hasFiles(directoryPath)) {
        clear
        std::cout << "Package alredy exists on the AUR\n";
        exit(1);
    }
    system(("cp PKGBUILD .SRCINFO /" + input).c_str());
    std::filesystem::current_path(directoryPath);
    system(("git -c init.defaultbranch=master clone ssh://aur@aur.archlinux.org/" + pkggit).c_str());
    system("git -c init.defaultBranch=master init");
    system(("git remote add label ssh://aur@aur.archlinux.org/" + pkggit).c_str());
    system("git add PKGBUILD .SRCINFO");
    string commitMessage;
    cout << "Enter your commit message: ";
    getline(cin, commitMessage);
    string gitCommand = "git commit -m \"" + commitMessage + "\"";
    system(gitCommand.c_str());
    system("git push");
    }
    else {
    //AUR downloader funtion here
    std::string pkggit = "https://aur.archlinux.org/" + pkg + ".git";
    std::cout << "Checking if package '" << pkg << "' exists\n";
    const std::string directoryPath = currentDirectory + "/" + pkg;
    std::filesystem::remove_all(directoryPath);
    system(("git clone --recurse --quiet " + pkggit).c_str());
    if (hasFiles(directoryPath)) {
        //Installing
        clear
        std::cout << "Package has been found on the AUR\n";
        //changing directory
        std::filesystem::current_path(directoryPath);
        //getting deps
        const std::string pkgbuildFilename = "PKGBUILD";
        readDependencies(pkgbuildFilename);
        //install dependencies
        int depsize = dependencies.size();
        std::vector<std::string> aurdeps;
        std::vector<std::string> regdeps;
        std::cout << "Found dependencies:\n";
        for (int i = 0; i < depsize; ++i) {
        std::string depwork = dependencies[i];
        int result = system(("sudo pacman -Q -q " + depwork).c_str());
        if (result == !0) {
            aurdeps.push_back(dependencies[i] + " ");
        }
        else {
            regdeps.push_back(dependencies[i] + " ");
        }
        }
        std::string depinstall = "sudo pacman -S ";
        for (const auto& dependency : regdeps) {
            depinstall += dependency + " ";
        }
        system((depinstall).c_str());
        if (!aurdeps.empty()) {
        std::cout << "Some depencencies need to be installed from the AUR." << std::endl;
        pausecmd();
        std::string depinstall = "eaur  ";
        for (const auto& dependency : regdeps) {
            depinstall += dependency + " ";
            system((depinstall).c_str());
            depinstall = "eaur ";
        }
        }
        const char* command = "makepkg -si";
        pausecmd();
        int excode = std::system(command);
        if (excode == 0) {
            std::cout << "Package installed successfully." << std::endl;
            pausecmd();
            std::filesystem::remove_all(directoryPath);
            exit(0);
        }
        else {
            std::cerr << "MAKEPKG command failed with exit code: " << excode << std::endl;
            pausecmd();
            std::filesystem::remove_all(directoryPath);
            exit(1);
        }
    } else {
        fail();
        exit(1);
    }
}
}
